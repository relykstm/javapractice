package zookeeper.zookeeper1;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;


@RestController
@CrossOrigin

public class HomeController {

    // @GetMapping("/")
    // public String home() {
    //     return "Hello";
    // }

    @GetMapping("/gorillatest")
    public String gorillaTest() {
        Gorilla George = new Gorilla();
        George.eatBananas();
        George.eatBananas();
        George.eatBananas();
        George.throwsomething();
        George.climb();
        int results = George.getEnergyLevel();
        return "George's Final Energy is " + results + " !!";
    }
    
    
}